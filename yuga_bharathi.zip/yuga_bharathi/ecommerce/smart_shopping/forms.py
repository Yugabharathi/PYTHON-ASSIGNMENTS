from django import forms


class CustomerForm(forms.modelForm):
    class Meta:
        model=smart_shopping
        field = ('first_name','last_name','age','doj')