from django.shortcuts import render
from django.http import HttpResponse
from .models import CustomerForm 
# Create your views here.
def first_view(request):
    Name = {'name':'yuga'}
    queryset = CustomerForm.objects.all()
    print("=====",queryset)
    return render(request,'First.temp.html',Name)

    if request.method=="POST":
        form = CustomerForm(request.POST)
        if form.is_valid():
            print('fff')
            form.save()
    return render(request,'First.temp.html',{'form':form})

def index(request):
    return HttpResponse('Accessed to anybody')