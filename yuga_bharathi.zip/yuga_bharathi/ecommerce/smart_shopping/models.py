from django.db import models


# Create your models here.
class CustomerForm(models.Model):
 Customer_name = models.CharField(max_length=30)
 price = models.IntegerField()
 no_of_products = models.IntegerField()
 created_at=models.DateTimeField(verbose_name="created")
 updated_at=models.DateTimeField(verbose_name="updated")